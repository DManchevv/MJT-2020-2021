package bg.sofia.uni.fmi.mjt.netflix.content.enums;

public enum Genre {
    ACTION, HORROR, COMEDY
}
