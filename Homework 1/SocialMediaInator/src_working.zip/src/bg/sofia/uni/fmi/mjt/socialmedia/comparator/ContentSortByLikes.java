package bg.sofia.uni.fmi.mjt.socialmedia.comparator;

import bg.sofia.uni.fmi.mjt.socialmedia.content.Content;

import java.util.Comparator;

public class ContentSortByLikes implements Comparator<Content> {

    @Override
    public int compare(Content o1, Content o2) {
        return ((o2.getNumberOfLikes() + o2.getNumberOfComments()) -
                (o1.getNumberOfComments() + o1.getNumberOfLikes()));
    }

}
