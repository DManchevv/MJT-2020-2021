package bg.sofia.uni.fmi.mjt.socialmedia.exceptions;

public class ContentNotFoundException extends Exception {
    public ContentNotFoundException(String message) {
        super(message);
    }
}
