package bg.sofia.uni.fmi.mjt.socialmedia;

import bg.sofia.uni.fmi.mjt.socialmedia.comparator.ContentSortByDate;
import bg.sofia.uni.fmi.mjt.socialmedia.comparator.ContentSortByLikes;
import bg.sofia.uni.fmi.mjt.socialmedia.comparator.SortUsernamesByMentions;
import bg.sofia.uni.fmi.mjt.socialmedia.content.Content;
import bg.sofia.uni.fmi.mjt.socialmedia.content.Post;
import bg.sofia.uni.fmi.mjt.socialmedia.content.Story;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.ContentNotFoundException;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.NoUsersException;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.UsernameAlreadyExistsException;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.UsernameNotFoundException;
import bg.sofia.uni.fmi.mjt.socialmedia.logs.UserActivityLog;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Collection;
import java.util.TreeMap;

public class EvilSocialInator implements SocialMediaInator {
    private List<String> accounts;
    private List<Story> stories;
    private List<Post> posts;
    private int contentCount;
    private Map<String, UserActivityLog> logger;

    public EvilSocialInator() {
        this.accounts = new ArrayList<>();
        this.posts = new ArrayList<>();
        this.stories = new ArrayList<>();
        this.contentCount = 0;
        this.logger = new HashMap<>();
    }

    @Override
    public void register(String username) throws UsernameAlreadyExistsException {
        if (username == null) {
            throw new IllegalArgumentException("Username is null!");
        }

        if (!accounts.isEmpty()) {
            if (accounts.contains(username)) {
                throw new UsernameAlreadyExistsException("Username already exists!");
            }
        }

        accounts.add(username);
        logger.put(username, new UserActivityLog());
    }

    @Override
    public String publishPost(String username, LocalDateTime publishedOn, String description)
            throws UsernameNotFoundException {

        if (username == null || publishedOn == null || description == null) {
            throw new IllegalArgumentException("One or more of the parameters are null!");
        }

        if (!accounts.contains(username)) {
            throw new UsernameNotFoundException("The inputted username is not found in the platform!");
        }

        String id = username + "-" + contentCount;
        contentCount++;
        if (publishedOn.plusDays(30).isAfter(LocalDateTime.now())) {
            posts.add(new Post(username, publishedOn, description, id));
        }

        logger.get(username).addPost(publishedOn, id);
        return id;
    }

    @Override
    public String publishStory(String username, LocalDateTime publishedOn, String description)
            throws UsernameNotFoundException {

        if (username == null || publishedOn == null || description == null) {
            throw new IllegalArgumentException("One or more of the parameters are null!");
        }

        if (!accounts.contains(username)) {
            throw new UsernameNotFoundException("The inputted username is not found in the platform!");
        }

        String id = username + "-" + contentCount;
        contentCount++;
        if (publishedOn.plusHours(24).isAfter(LocalDateTime.now())) {
            stories.add(new Story(username, publishedOn, description, id));
        }

        logger.get(username).addStory(publishedOn, id);
        return id;
    }

    @Override
    public void like(String username, String id) throws UsernameNotFoundException, ContentNotFoundException {
        if (username == null || id == null) {
            throw new IllegalArgumentException("One or more of the parameters are null!");
        }

        if (!accounts.contains(username)) {
            throw new UsernameNotFoundException("The inputted username is not found in the platform!");
        }

        boolean isFound = false;
        for (Story current : stories) {
            if (current.getId().equals(id)) {
                isFound = true;
                current.setLikes(current.getNumberOfLikes() + 1);
                break;
            }
        }

        if (!isFound) {
            for (Post current : posts) {
                if (current.getId().equals(id)) {
                    isFound = true;
                    current.setLikes(current.getNumberOfLikes() + 1);
                    break;
                }
            }
        }

        if (!isFound) {
            throw new ContentNotFoundException("There isn't a story with the inputted id in the platform!");
        }

        logger.get(username).addLike(LocalDateTime.now(), id);
    }

    @Override
    public void comment(String username, String text, String id)
            throws UsernameNotFoundException, ContentNotFoundException {

        if (username == null || text == null || id == null) {
            throw new IllegalArgumentException("One or more of the parameters are null!");
        }

        if (!accounts.contains(username)) {
            throw new UsernameNotFoundException("The inputted username is not found in the platform!");
        }

        boolean isFound = false;
        for (Story current : stories) {
            if (current.getId().equals(id)) {
                isFound = true;
                current.setComments(current.getNumberOfComments() + 1);
                break;
            }
        }

        if (!isFound) {
            for (Post current : posts) {
                if (current.getId().equals(id)) {
                    isFound = true;
                    current.setComments(current.getNumberOfComments() + 1);
                    break;
                }
            }
        }

        if (!isFound) {
            throw new ContentNotFoundException("There isn't a story with the inputted id in the platform!");
        }

        logger.get(username).addComment(LocalDateTime.now(), text, id);
    }

    @Override
    public Collection<Content> getNMostPopularContent(int n) {
        if (n < 0) {
            return null;
        }

        List<Content> content = new ArrayList<>();
        content.addAll(stories);
        content.addAll(posts);
        ContentSortByLikes comparator = new ContentSortByLikes();
        Collections.sort(content, comparator);
        List<Content> mostPopular = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            mostPopular.add(content.get(i));
        }

        return mostPopular;
    }

    @Override
    public Collection<Content> getNMostRecentContent(String username, int n) throws UsernameNotFoundException {
        if (username == null || n < 0) {
            return null;
        }
        if (!accounts.contains(username)) {
            throw new UsernameNotFoundException("Username does not exist in the platform!");
        }
        List<Content> content = new ArrayList<>();
        content.addAll(stories);
        content.addAll(posts);
        Map<String, LocalDateTime> currentUsernameContent = new HashMap<>();
        ContentSortByDate comparator = new ContentSortByDate(currentUsernameContent);
        for (Story current : stories) {
            if (current.getUsername().equals(username)) {
                currentUsernameContent.put(current.getId(), current.getPublishedOn());
                break;
            }
        }

        for (Post current : posts) {
            if (current.getUsername().equals(username)) {
                currentUsernameContent.put(current.getId(), current.getPublishedOn());
                break;
            }
        }

        TreeMap<String, LocalDateTime> sortedContent = new TreeMap<>(comparator);
        sortedContent.putAll(currentUsernameContent);
        int counter = 0;
        List<Content> mostRecentContent = new ArrayList<>();
        for (String currentId : sortedContent.keySet()) {
            if (counter == n) {
                break;
            }

            for (Content current : content) {
                if (current.getId().equals(currentId)) {
                    mostRecentContent.add(current);
                    break;
                }
            }

            counter++;
        }

        return mostRecentContent;
    }

    @Override
    public String getMostPopularUser() throws NoUsersException {
        if (accounts.isEmpty()) {
            throw new NoUsersException("There are currently no users in the platform!");
        }
        Map<String, Integer> usernameMentions = new HashMap<>();
        List<Content> content = new ArrayList<>();
        content.addAll(stories);
        content.addAll(posts);
        for (Content currentContent : content) {
            for (String currentUsername : currentContent.getMentions()) {
                if (accounts.contains(currentUsername)) {
                    if (!usernameMentions.containsKey(currentUsername)) {
                        usernameMentions.put(currentUsername, 1);
                    } else {
                        usernameMentions.put(currentUsername, usernameMentions.get(currentUsername) + 1);
                    }
                }
            }
        }
        if (usernameMentions.isEmpty()) {
            return accounts.get(0);
        }

        SortUsernamesByMentions comparator = new SortUsernamesByMentions(usernameMentions);
        TreeMap<String, Integer> sortedMentions = new TreeMap<>(comparator);
        sortedMentions.putAll(usernameMentions);
        return sortedMentions.firstKey();
    }

    @Override
    public Collection<Content> findContentByTag(String tag) {
        if (tag == null) {
            throw new IllegalArgumentException("Tag is null!");
        }

        List<Content> content = new ArrayList<>();
        content.addAll(stories);
        content.addAll(posts);
        List<Content> contentWithTag = new ArrayList<>();
        for (Content current : content) {
            for (String currentTag : current.getTags()) {
                if (currentTag.equals(tag)) {
                    contentWithTag.add(current);
                    break;
                }
            }
        }

        return contentWithTag;
    }

    @Override
    public List<String> getActivityLog(String username) {
        return logger.get(username).getLog();
    }
}
