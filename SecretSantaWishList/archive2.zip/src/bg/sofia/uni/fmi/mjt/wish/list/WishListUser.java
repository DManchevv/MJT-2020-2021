package bg.sofia.uni.fmi.mjt.wish.list;

public record WishListUser(String username, String password) {

}
