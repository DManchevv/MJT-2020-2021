package bg.sofia.uni.fmi.mjt.wish.list;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import java.util.LinkedList;
import java.util.List;

public class ClientRequestHandlerTest {

    private static ClientRequestHandler clientRequestHandler;

    @Before
    public void setUp() {
        clientRequestHandler = new ClientRequestHandler(null, null, null);
    }


}
