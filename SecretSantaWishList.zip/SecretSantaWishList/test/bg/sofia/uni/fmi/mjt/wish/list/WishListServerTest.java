package bg.sofia.uni.fmi.mjt.wish.list;

import org.junit.Test;

public class WishListServerTest {

    @Test
    public void testWishServerListTest() {

    }
}
