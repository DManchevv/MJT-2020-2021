package bg.sofia.uni.fmi.mjt.wish.list;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.LinkedList;
import java.util.List;


public class UniqueVerifierTest {

    private static UniqueVerifier verifier;

    @Before
    public void setUp() {
        verifier = new UniqueVerifier();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetUsernamesWithNullArgument() {
        verifier.isUserAlreadyRegistered(null, "Pesho");
    }

    @Test
    public void testGetUsernamesWithEmptyAccountsArray() {
        List<WishListUser> accounts = new LinkedList<>();
        String assertMessage = "After getting an empty list as an argument, this method should return true.";

        assertTrue(assertMessage, verifier.isUserAlreadyRegistered(accounts, "Pesho2"));
    }

    @Test
    public void testGetUsernamesWithNotEmptyArray() {
        List<WishListUser> accounts = new LinkedList<>();
        String assertMessage = "Return a list with all registered usernames.";

        accounts.add(new WishListUser("Zevs", "123"));
        accounts.add(new WishListUser("Mohamed", "456"));

        assertTrue(assertMessage, verifier.isUserAlreadyRegistered(accounts, "Zevs"));
    }

}
