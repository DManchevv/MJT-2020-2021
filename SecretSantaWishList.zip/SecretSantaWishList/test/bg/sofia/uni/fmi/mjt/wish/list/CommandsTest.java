package bg.sofia.uni.fmi.mjt.wish.list;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public class CommandsTest {

    private static Commands command;
    private static PrintWriter out;

    @Before
    public void setUp() {
        command = new Commands();
        out = new PrintWriter(System.out);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRegisterCommandWithNullArgument() {
        command.registerCommand(null, new String[]{"register", "b", "c"}, new AtomicBoolean(false), null);
    }

    @Test
    public void testRegisterCommandWithAlreadyTakenUsername() {
        List<WishListUser> accounts = new LinkedList<>();
        String assertMessage = "Appropriate message for already taken username is returned.";
        String expected = "[ Username Kaloyan is already taken, select another one ]";

        accounts.add(new WishListUser("Kaloyan", "12345"));

        assertEquals(assertMessage, expected, command.registerCommand(accounts,
                new String[]{"register", "Kaloyan", "qwerty"}, new AtomicBoolean(false), out));
    }

    @Test
    public void testRegisterCommandWhileLoggedIn() {
        List<WishListUser> accounts = new LinkedList<>();
        String assertMessage = "Appropriate message for already logged in user is returned.";
        String expected = "[ You cannot use the register command when you are already logged in ]";

        assertEquals(assertMessage, expected, command.registerCommand(accounts, new String[]{"register", ""},
                new AtomicBoolean(true), out));
    }

    @Test
    public void testRegisterCommandWithUsernameContainingIllegalSymbols() {
        List<WishListUser> accounts = new LinkedList<>();
        String invalidUsername = "!@Pe$0";
        String assertMessage = "Appropriate message for illegal symbols in username is returned.";
        String expected = "[ Username " + invalidUsername + " is invalid, select a valid one ]";

        assertEquals(assertMessage, expected, command.registerCommand(accounts,
                new String[]{"register", invalidUsername, "1234"}, new AtomicBoolean(false), out));
    }

    @Test
    public void testRegisterCommandWithUsernameContainingSpecialAllowedSymbols() {
        List<WishListUser> accounts = new LinkedList<>();
        String validUsername = "Blizzard_Entertainment-1991-Inc.";
        String assertMessage = "Successfully registered the user and returned appropriate message.";
        String expected = "[ Username " + validUsername + " successfully registered ]";

        assertEquals(assertMessage, expected, command.registerCommand(accounts,
                new String[]{"register", validUsername, "irvineUSA91"}, new AtomicBoolean(false), out));
    }

    @Test
    public void testRegisterCommandWithNormalUsername() {
        List<WishListUser> accounts = new LinkedList<>();
        String validUsername = "Mitko31";
        String assertMessage = "Successfully registered the user and appropriate message returned.";
        String expected ="[ Username " + validUsername + " successfully registered ]";

        assertEquals(assertMessage, expected, command.registerCommand(accounts,
                new String[]{"register", validUsername, "31111"}, new AtomicBoolean(false), out));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testLoginCommandWithNullArgument() {
        command.loginCommand(null, new String[]{}, new AtomicBoolean(false), out);
    }

    @Test
    public void testLoginCommandWhileLoggedIn() {
        List<WishListUser> accounts = new LinkedList<>();
        String assertMessage = "Appropriate message for already logged in user is returned.";
        String expected = "[ You cannot use the login command when you are already logged in ]";

        assertEquals(assertMessage, expected, command.loginCommand(accounts, new String[]{"login", ""},
                new AtomicBoolean(true), out));
    }

    @Test
    public void testLoginCommandWithNonexistentUser() {
        List<WishListUser> accounts = new LinkedList<>();
        String assertMessage = "Appropriate message for non-existent user is returned.";
        String expected = "[ Invalid username/password combination ]";

        assertEquals(assertMessage, expected, command.loginCommand(accounts,
                new String[]{"login", "Mohamed" , "kekw123"}, new AtomicBoolean(false), out));
    }

    @Test
    public void testLoginCommandWithInvalidPassword() {
        List<WishListUser> accounts = new LinkedList<>();
        String assertMessage = "Appropriate message for invalid password is returned.";
        String expected = "[ Invalid username/password combination ]";

        accounts.add(new WishListUser("Stefan" , "stef123"));

        assertEquals(assertMessage, expected, command.loginCommand(accounts,
                new String[]{"login", "Stefan", "lordship"}, new AtomicBoolean(false), out));
    }

    @Test
    public void testLoginCommandWithValidCredentials() {
        List<WishListUser> accounts = new LinkedList<>();
        String assertMessage = "Successfully logged in the user and returned appropriate message.";
        String expected = "[ User Zdravko successfully logged in ]";

        accounts.add(new WishListUser("Zdravko", "Abcd1234"));

        assertEquals(assertMessage, expected, command.loginCommand(accounts,
                new String[]{"login" , "Zdravko", "Abcd1234"}, new AtomicBoolean(false), out));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testLogoutCommandWithNullArgument() {
        command.logoutCommand(new AtomicBoolean(false), null);
    }

    @Test
    public void testLogoutCommandWhileNotLoggedIn() {
        String assertMessage = "Appropriate message for not being logged in returned.";
        String expected = "[ You are not logged in ]";

        assertEquals(assertMessage, expected, command.logoutCommand(new AtomicBoolean(false), out));
    }

    @Test
    public void testLogoutCommandWhileLoggedIn() {
        String assertMessage = "Logout successfully and return appropriate message.";
        String expected = "[ Successfully logged out ]";

        assertEquals(assertMessage, expected, command.logoutCommand(new AtomicBoolean(true), out));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPostWishCommandWithNullArgument() {
        List<WishListUser> accounts = new LinkedList<>();

        command.postWishCommand(accounts, new String[]{"post-wish", "franklin", "kolelo"}, null, out, null);
    }

    @Test
    public void testPostWishCommandWhileNotLoggedIn() {
        List<WishListUser> accounts = new LinkedList<>();
        Map<String, List<String>> wishContainer = new ConcurrentHashMap<>();

        String assertMessage = "Appropriate message for not logged in user returned.";
        String expected = "[ You are not logged in ]";

        assertEquals(assertMessage, expected, command.postWishCommand(accounts, new String[]{"post-wish", "a", "b"},
                new AtomicBoolean(false), out, wishContainer));
    }

    @Test
    public void testPostWishCommandWithNotRegisteredReceiver() {
        List<WishListUser> accounts = new LinkedList<>();
        Map<String, List<String>> wishContainer = new ConcurrentHashMap<>();

        String assertMessage = "Appropriate message for student not registered returned.";
        String expected = "[ Student with username Zdravko is not registered ]";

        assertEquals(assertMessage, expected, command.postWishCommand(accounts,
                new String[]{"post-wish", "Zdravko", "parcal"}, new AtomicBoolean(true), out, wishContainer));
    }

    @Test
    public void testPostWishCommandWithGiftAlreadySubmittedToReceiver() {
        List<WishListUser> accounts = new LinkedList<>();
        Map<String, List<String>> wishContainer = new ConcurrentHashMap<>();

        String assertMessage = "Appropriate message for already submitted gift to this user returned.";
        String expected = "[ The same gift for student Asen was already submitted ]";

        assertEquals(assertMessage, expected, command.postWishCommand(accounts,
                new String[]{"post-wish", "Mitko", "kolelo"}, new AtomicBoolean(true), out, wishContainer));
    }
}
