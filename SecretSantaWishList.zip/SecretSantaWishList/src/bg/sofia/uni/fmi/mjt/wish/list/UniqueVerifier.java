package bg.sofia.uni.fmi.mjt.wish.list;

import java.util.List;
import java.util.Map;

public class UniqueVerifier {

    public boolean isGiftAlreadySubmitted(Map<String, List<String>> wishContainer, String[] gifts) {

        if (wishContainer == null || gifts == null) {
            throw new IllegalArgumentException("Null argument in isGiftAlreadySubmitted method");
        }

        if (gifts.length < 3) {
            return false;
        }

        for (List<String> currentUserGifts : wishContainer.values()) {
            for (int i = 2; i < gifts.length; i++) {
                if (currentUserGifts.contains(gifts[i])) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean isUserAlreadyRegistered(List<WishListUser> accounts, String user) {

        if (accounts == null || user == null) {
            throw new IllegalArgumentException("Null argument in isUserAlreadyRegistered method.");
        }

        for (WishListUser currentUser : accounts) {
            if (currentUser.username().equals(user)) {
                return true;
            }
        }

        return false;
    }
}
