package bg.sofia.uni.fmi.mjt.wish.list;

import java.io.*;
import java.net.Socket;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class ClientRequestHandler implements Runnable {

    private final Socket socket;
    private final AtomicBoolean loggedIn;
    private final Commands commandMenu;
    private final File database;
    private String currentUser;
    private Map<String, Task> PersonalTasks;
    private Map<String, Task> Inbox;
    private Map<String, Collaboration> collaborations;

    public ClientRequestHandler(Socket socket) {
        this.socket = socket;
        this.loggedIn = new AtomicBoolean(false);
        this.commandMenu = new Commands();
        this.database = new File("database.db");
        this.PersonalTasks = new HashMap<>();
        this.Inbox = new HashMap<>();
        this.collaborations = new HashMap<>();
    }

    @Override
    public void run() {
        //TODO refactor the whole method in order to have cleaner code
        try (PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            String inputLine;

            outer:
            while (!Thread.currentThread().isInterrupted()) {
                if (in.ready()) {
                    inputLine = in.readLine();

                    String[] lineWords = inputLine.split("\\s+");

                    if ("register".equals(lineWords[0])) {

                        if (loggedIn.get()) {
                            out.println("You cannot register while logged in!");
                            continue;
                        }

                        if (lineWords.length != 3) {
                            out.println("Invalid input!");
                            continue;
                        }

                        String result = commandMenu.register(lineWords[1], lineWords[2], database);

                        if (result.contains("successfully")) {
                            currentUser = lineWords[1];
                            loggedIn.set(true);
                        }

                        out.println(result);
                    } else if ("add-task".equals(lineWords[0])) {
                        if (lineWords.length == 1) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        if (!lineWords[1].contains("--name")) {
                            out.println("Every task requires a name!");
                            continue;
                        }

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        String name;
                        String date = null;
                        String dueDate = null;
                        String description = null;

                        name = lineWords[1].split("=")[1];

                        if (inputLine.contains("--date")) {
                            date = lineWords[2].split("=")[1];

                            if (inputLine.contains("--due-date")) {
                                dueDate = lineWords[3].split("=")[1];
                            }

                            if (inputLine.contains("--description")) {
                                description = lineWords[4].split("=")[1];
                                for (int i = 5; i < lineWords.length; i++) {
                                    description += " ";
                                    description += lineWords[i];
                                }
                            }


                        } else if (inputLine.contains("--description")) {
                            description = lineWords[2].split("=")[1];
                            for (int i = 3; i < lineWords.length; i++) {
                                description += " ";
                                description += lineWords[i];
                            }
                        }

                        Task task = commandMenu.addTask(name, date, dueDate, description);

                        if (task.getDate() != null) {
                            for (Task currentTask : PersonalTasks.values()) {
                                if (currentTask.getDate().equals(task.getDate()) &&
                                        currentTask.getName().equals(task.getName())) {

                                    out.println("[ There cannot be 2 tasks with the same name and date ]");
                                    continue outer;

                                }
                            }

                            PersonalTasks.put(name, task);
                        }
                        else {
                            if (Inbox.containsKey(name)) {
                                out.println("[ There cannot be 2 tasks with the same name in inbox ]");
                            }

                            Inbox.put(name, task);
                        }

                        out.println("The task was successfully added!");
                    } else if ("update-task".equals(lineWords[0])) {
                        if (lineWords.length < 2) {
                            out.println(" [ Wrong command syntax ] ");
                            continue;
                        }

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        if (!lineWords[1].contains("--name")) {
                            out.println("Every task requires a name!");
                            continue;
                        }

                        String name = lineWords[1].split("=")[1];
                        int dateIndex = CleanMethods.VariableRefactoring.findIndexByString(lineWords, "--date");
                        int dueIndex = CleanMethods.VariableRefactoring.findIndexByString(lineWords, "--dueDate");
                        int descIndex = CleanMethods
                                .VariableRefactoring.findIndexByString(lineWords, "--description");

                        if (PersonalTasks.containsKey(name)) {
                            if (dateIndex != -1) {
                                PersonalTasks.get(name).setDate(CleanMethods
                                        .VariableRefactoring.dateConverter(lineWords[dateIndex].split("=")[1]));
                            }

                            if (dueIndex != -1) {
                                PersonalTasks.get(name).setDate(CleanMethods
                                        .VariableRefactoring.dateConverter(lineWords[dueIndex].split("=")[1]));
                            }

                            if (descIndex != -1) {
                                PersonalTasks.get(name).setDescription(CleanMethods
                                        .VariableRefactoring.createDescription(lineWords, descIndex));
                            }

                            if (dateIndex != -1 || dueIndex != -1 || descIndex != -1) {
                                out.println("[ Task with name " + name + " was successfully updated ]");
                            }

                        } else if (Inbox.containsKey(name)) {
                            PersonalTasks.get(name).setDescription(CleanMethods
                                    .VariableRefactoring.createDescription(lineWords, descIndex));

                            out.println("[ Task with name " + name + " was successfully updated ]");
                        }

                    } else if ("delete-task".equals(lineWords[0])) {

                        if (lineWords.length == 1) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        if (!lineWords[1].contains("--name")) {
                            out.println("[ This command must contain --name flag ]");
                            continue;
                        }

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        String name = lineWords[1].split("=")[1];

                        if (!PersonalTasks.containsKey(name)) {
                            out.println("[ There isn't task with such name ]");
                            continue;
                        }

                        int dateIndex = CleanMethods.VariableRefactoring.findIndexByString(lineWords, "--date");

                        if (dateIndex != -1) {
                            String date = lineWords[dateIndex].split("=")[1];
                            LocalDate convertedDate = CleanMethods.VariableRefactoring.dateConverter(date);
                            if (PersonalTasks.get(name).getDate().equals(convertedDate)) {
                                PersonalTasks.remove(name);
                                out.println("[ Task with name " + name + " was successfully removed ]");
                                continue;
                            }
                        }

                        PersonalTasks.remove(name);
                        out.println("[ Task with name " + name + " was successfully removed ]");

                    } else if ("get-task".equals(lineWords[0])) {

                        if (lineWords.length < 2 || lineWords.length > 3) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        if (!lineWords[1].contains("--name")) {
                            out.println("[ This command must contain --name flag ]");
                            continue;
                        }

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        String name = lineWords[1].split("=")[1];
                        int dateIndex = CleanMethods.VariableRefactoring.findIndexByString(lineWords, "--date");

                        if (dateIndex != -1) {
                            String date = lineWords[dateIndex].split("=")[1];
                            LocalDate convertedDate = CleanMethods.VariableRefactoring.dateConverter(date);

                            if (PersonalTasks.get(name).getDate().equals(convertedDate)) {
                                out.println(PersonalTasks.get(name).toString());
                                continue;
                            }

                        }

                        out.println(PersonalTasks.get(name).toString());

                    } else if ("list-tasks".equals(lineWords[0])) {
                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        int completedIndex;
                        int dateIndex;
                        boolean completed = false;
                        boolean sameDateFound = false;
                        boolean completedFound = false;
                        LocalDate date = null;

                        completedIndex = CleanMethods
                                .VariableRefactoring.findIndexByString(lineWords, "--completed");

                        dateIndex = CleanMethods
                                .VariableRefactoring.findIndexByString(lineWords, "--date");

                        if (completedIndex != -1) {
                            if (lineWords[completedIndex].split("=")[1].equals("true")) {
                                completed = true;
                            }
                        }

                        if (dateIndex != -1) {
                            date = CleanMethods
                                    .VariableRefactoring.dateConverter(lineWords[dateIndex].split("=")[1]);

                        }

                        for (Task task : PersonalTasks.values()) {
                            if (date != null) {
                                if (date.equals(task.getDate())) {
                                    out.println(task);
                                    sameDateFound = true;
                                }
                            } else if (completed) {
                                if (task.getFinished()) {
                                    out.println(task);
                                    completedFound = true;
                                }
                            } else {
                                out.println(task);
                            }
                        }

                        if (dateIndex != -1 && !sameDateFound) {
                            out.println("[ There are no tasks with this date ]");
                        }

                        if (completed && !completedFound) {
                            out.println("[ There are no completed tasks ]");
                        }

                    } else if ("list-dashboard".equals(lineWords[0])) {
                        if (lineWords.length != 1) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        if (PersonalTasks.size() == 0) {
                            out.println("[ There are no tasks for today ]");
                            continue;
                        }

                        for (Task task : PersonalTasks.values()) {
                            if (task.getDate().equals(LocalDate.now())) {
                                out.println(task);
                            }
                        }

                    } else if ("finish-task".equals(lineWords[0])) {
                        if (lineWords.length != 2) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        String name = lineWords[1].split("=")[1];
                        PersonalTasks.get(name).setFinished(true);

                    } else if ("add-collaboration".equals(lineWords[0])) {
                        if (lineWords.length != 2) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        String name = lineWords[1].split("=")[1];
                        Collaboration newCollaboration = new Collaboration(currentUser);

                        collaborations.put(name, newCollaboration);

                    } else if ("delete-collaboration".equals(lineWords[0])) {
                        if (lineWords.length != 2) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        String name = lineWords[1].split("=")[1];

                        if (currentUser.equals(collaborations.get(name).getOwner())) {
                            collaborations.remove(name);
                        } else {
                            out.println("[ Only the owner of the collaboration can delete it ]");
                        }

                    } else if ("add-user".equals(lineWords[0])) {
                        if (lineWords.length != 3) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        int collaborationIndex = CleanMethods
                                .VariableRefactoring.findIndexByString(lineWords, "--collaboration");

                        int userIndex = CleanMethods
                                .VariableRefactoring.findIndexByString(lineWords, "--user");

                        if (collaborationIndex != 1 || userIndex != 2) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        String collaborationName = lineWords[1].split("=")[1];
                        String username = lineWords[2].split("=")[1];

                        collaborations.get(collaborationName).addUser(username);

                    } else if ("assign-task".equals(lineWords[0])) {
                        if (lineWords.length != 4) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        int collaborationIndex = CleanMethods
                                .VariableRefactoring.findIndexByString(lineWords, "--collaboration");

                        int userIndex = CleanMethods
                                .VariableRefactoring.findIndexByString(lineWords, "--user");

                        int taskIndex = CleanMethods
                                .VariableRefactoring.findIndexByString(lineWords, "--task");

                        if (collaborationIndex != 1 || userIndex != 2 || taskIndex != 3) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        String collaborationName = lineWords[1].split("=")[1];
                        String username = lineWords[2].split("=")[1];
                        String taskName = lineWords[3].split("=")[1];

                        //TODO finish this method

                    } else if ("list-users".equals(lineWords[0])) {
                        if (lineWords.length != 2) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        if (!lineWords[1].split("=")[0].equals("--collaboration")) {
                            out.println("[ Wrong command syntax ]");
                            continue;
                        }

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                            continue;
                        }

                        String name = lineWords[1].split("=")[1];

                        for (String user : collaborations.get(name).getUsers()) {
                            out.println(user);
                        }

                    } else if ("login".equals(lineWords[0])) {

                        if (loggedIn.get()) {
                            out.println("You are already logged in!");
                            continue;
                        }

                        String result = commandMenu.login(lineWords[1], lineWords[2], database);

                        if (result.contains("successfully")) {
                            currentUser = lineWords[1];
                            loggedIn.set(true);
                        }

                        out.println(result);

                    } else if ("logout".equals(lineWords[0])) {

                        if (!loggedIn.get()) {
                            out.println("[ You must be logged in ]");
                        }

                        loggedIn.set(false);
                        out.println("[ You have been logged out from the system ]");

                    } else if ("help".equals(lineWords[0])) {

                        out.println("[ add-task --name=<name> --date=<date> --due-date=<due-date> --desc=<desc> ]");
                        out.println("[ update-task --name=<name> --date=<date> --due-date=<due-date> --desc=<desc> ]");
                        out.println("[ delete-task --name=<task_name> ]");
                        out.println("[ delete-task --name=<task_name> --date=<date> ]");
                        out.println("[ get-task --name=<task_name> ]");
                        out.println("[ get-task --name=<task_name> --date=<date> ]");
                        out.println("[ list-tasks ]");
                        out.println("[ list-tasks --completed=true ]");
                        out.println("[ list-tasks --date=<date> ]");
                        out.println("[ list-dashboard ]");
                        out.println("[ finish-task --name=<name> ]");

                    } else if ("disconnect".equals(lineWords[0])) {
                        loggedIn.set(false);
                        out.println("[ Disconnected from server ]");
                        break;
                    } else {
                        out.println("[ Unknown Command ]");
                    }
                }

            }

            loggedIn.set(false);
            out.println("[ Disconnected from server ]");

        } catch (IOException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }
}