package bg.sofia.uni.fmi.mjt.wish.list;

import java.time.LocalDate;

public class CleanMethods {
    public static class VariableRefactoring {

        public static int findIndexByString(String[] arr, String word) {

            for (int i = 0; i < arr.length; i++) {
                if(arr[i].contains(word)) {
                    return i;
                }
            }

            return -1;
        }

        public static String createDescription(String[] arr, int descIndex) {
            String description;
            description = arr[descIndex].split("=")[1];
            for (int i = descIndex + 1; i < arr.length; i++) {
                description += " ";
                description += arr[i];
            }

            return description;
        }

        public static LocalDate dateConverter(String date) {
            int year = Integer.parseInt(date.split("-")[0]);
            int month = Integer.parseInt(date.split("-")[1]);
            int day = Integer.parseInt(date.split("-")[2]);
            return LocalDate.of(year, month, day);
        }

    }
}
