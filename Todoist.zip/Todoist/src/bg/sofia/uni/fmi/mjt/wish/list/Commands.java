package bg.sofia.uni.fmi.mjt.wish.list;

import java.io.*;
import java.time.LocalDate;

public class Commands {

    public String register(String username, String password, File file) {
        if (username == null || password == null) {
            return("Incorrect input!");
        }

        // TODO username verification symbols

        if (FileOperations.findUsername(username, file)) {
            return("User with name " + username + " already exists!");
        }

        FileOperations.saveNewAccount(username, password, file);
        return("User " + username + " successfully registered!");
    }

    public String login(String username, String password, File file) {
        if (username == null || password == null) {
            return("Incorrect input!");
        }

        if (FileOperations.findAccount(username, password, file)) {
            return("Hi, " + username + " . You have successfully logged in!");
        }

        return("Username or password is invalid!");

    }

    public Task addTask(String name, String date, String dueDate, String description) {

        LocalDate convertedDate = null;
        LocalDate convertedDueDate = null;

        if (date != null) {
            int year = Integer.parseInt(date.split("-")[0]);
            int month = Integer.parseInt(date.split("-")[1]);
            int day = Integer.parseInt(date.split("-")[2]);
            convertedDate = LocalDate.of(year, month, day);
        }

        if (dueDate != null) {
            int year = Integer.parseInt(dueDate.split("-")[0]);
            int month = Integer.parseInt(dueDate.split("-")[1]);
            int day = Integer.parseInt(dueDate.split("-")[2]);
            convertedDueDate = LocalDate.of(year, month, day);
        }

        return(new Task(name, convertedDate, convertedDueDate, description));
    }

    public static class FileOperations {

        public static boolean findAccount(String username, String password, File file) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))){
                String line;

                while ((line = reader.readLine()) != null) {
                    String[] lineWords = line.split("\\s+");

                    if (lineWords[0].equals(username) && lineWords[2].equals(password)) {
                        return true;
                    }

                }

            } catch (IOException e) {
                System.out.println("Error reading from file.");
            }

            return false;
        }

        public static void saveNewAccount(String username, String password, File file) {
            try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
                writer.write(username + " : " + password);
                writer.println();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public static boolean findUsername(String username, File file) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))){
                String line;

                while ((line = reader.readLine()) != null) {
                    String[] lineWords = line.split("\\s+");

                    if (lineWords[0].equals(username)) {
                        return true;
                    }

                }

            } catch (IOException e) {
                System.out.println("Error reading from file.");
            }

            return false;
        }

    }
}
