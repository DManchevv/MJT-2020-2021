package bg.sofia.uni.fmi.mjt.wish.list;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Collaboration {
    private final String owner;
    private List<String> users;
    private Map<String, Task> sharedTasks;
    private Map<String, Map<String, Task>> assignedTasks;

    public Collaboration(String owner) {
        this.owner = owner;
        users = new ArrayList<>();
        sharedTasks = new ConcurrentHashMap<>();
        assignedTasks = new ConcurrentHashMap<>();
    }

    public String getOwner() {
        return owner;
    }

    public List<String> getUsers() {
        return users;
    }

    public void addTask(String username, String taskName, Task task) {
        task.setName(taskName);
        sharedTasks.put(username, task);
    }

    public void assignTask(String username, Map<String,Task> tasks) {
        assignedTasks.put(username, tasks);
    }

    public void addUser(String username) {
        users.add(username);
    }

}
